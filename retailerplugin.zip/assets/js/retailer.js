jQuery(document).ready(function(){

    var ajaxurl = "/wp-admin/admin-ajax.php";

    // jQuery(function() {
    //     jQuery('#chkveg').multiselect({
    //         includeSelectAllOption: true
    //     });
    // });

    /* Get Distributor Category Product */
    jQuery(document).on("click", ".import_product_btn .product_import", function(){
        var cat_id = new Array();
        jQuery("input[term-id]:checked").each(function() {
            cat_id.push(jQuery(this).attr('term-id'));
        });

        var retailer_key_id = jQuery('#retailer_key_id').val();
        var retailer_id     = jQuery('#retailer_id').val();
        var distributor_url = jQuery('#distributor_url').val();
        var category        = cat_id;

        jQuery('.product_import_success').remove();
        jQuery('.product_import_notice').remove();
        
        if (category.length >= 1) {
            jQuery.ajax({
                type: "post",
                dataType: "json",
                url: ajaxurl,
                data : {
                    retailer_key_id: retailer_key_id,
                    retailer_id: retailer_id,
                    distributor_url: distributor_url,
                    category: category,
                    action: "get_category_products"
                },
                success: function(response){
                    jQuery('.import_product_btn').after('<p class="product_import_success">Product Import Successfully!</p.');
                    // This will reload the page after a delay of 3 seconds
                    window.setTimeout(function(){location.reload()},3000)
                }
            });
        }else{
            jQuery('.import_product_btn').after('<p class="product_import_notice">Please Select atleast one category!</p.');
        }
    });

    jQuery( '#add-row' ).on('click', function() {
        var row = jQuery( '.empty-row.screen-reader-text' ).clone(true);
        row.removeClass( 'empty-row screen-reader-text' );
        row.insertBefore( '#repeatable-fieldset-one tbody>tr:last' );
        return false;
    });

    jQuery( '.remove-row' ).on('click', function() {
        jQuery(this).parents('tr').remove();
        return false;
    });
});

jQuery(document).ready(function () {
    // Setup - add a text input to each footer cell
    // jQuery('.table-view-list.retailers thead tr').clone(true).addClass('filters').appendTo('.table-view-list.retailers thead');
 
    var table = jQuery('.table-view-list.product_logs, .table-view-list.distributors').DataTable({
        orderCellsTop: true,
        fixedHeader: true,
        initComplete: function () {
            var api = this.api();
 
            // For each column
            api
                .columns()
                .eq(0)
                .each(function (colIdx) {
                    // Set the header cell to contain the input element
                    var cell = jQuery('.filters th').eq(
                        jQuery(api.column(colIdx).header()).index()
                    );
                    var title = jQuery(cell).text();
                    jQuery(cell).html('<input type="text" placeholder="' + title + '" />');
 
                    // On every keypress in this input
                    jQuery(
                        'input',
                        jQuery('.filters th').eq(jQuery(api.column(colIdx).header()).index())
                    )
                        .off('keyup change')
                        .on('change', function (e) {
                            // Get the search value
                            jQuery(this).attr('title', jQuery(this).val());
                            var regexr = '({search})'; //jQuery(this).parents('th').find('select').val();
 
                            var cursorPosition = this.selectionStart;
                            // Search the column for that value
                            api
                                .column(colIdx)
                                .search(
                                    this.value != ''
                                        ? regexr.replace('{search}', '(((' + this.value + ')))')
                                        : '',
                                    this.value != '',
                                    this.value == ''
                                )
                                .draw();
                        })
                        .on('keyup', function (e) {
                            e.stopPropagation();
 
                            jQuery(this).trigger('change');
                            jQuery(this)
                                .focus()[0]
                                .setSelectionRange(cursorPosition, cursorPosition);
                        });
                });
        },
    });
});