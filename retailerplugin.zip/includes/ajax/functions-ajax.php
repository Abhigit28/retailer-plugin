<?php 

add_action( 'wp_ajax_nopriv_retailer_key_verify', 'retailer_key_verify' );
add_action( 'wp_ajax_retailer_key_verify', 'retailer_key_verify' );
function retailer_key_verify() {
    // WP Globals
    global $wpdb;
    $retailer_id     = trim($_REQUEST['retailer_id']);
    $retailer_key_id = trim($_REQUEST['retailer_key_id']);
    $distributor_url = trim($_REQUEST['distributor_url']);

    $distributor_table = $wpdb->prefix.'distributor_list';
    $distributor_query = $wpdb->prepare("SELECT * FROM $distributor_table WHERE retailer_id = $retailer_id AND retailer_key_id = '$retailer_key_id' AND distributor_url = '$distributor_url'");

    $key_id_found = $wpdb->get_results($distributor_query);

    if($key_id_found){
        echo json_encode(array('status' => true, 'message' => 'Retailer Key already exists')); 
        exit;
    }

    $distributorurl_query = $wpdb->prepare("SELECT * FROM $distributor_table WHERE distributor_url = '$distributor_url'");
    $distributorurl_found = $wpdb->get_results($distributorurl_query);

    if($distributorurl_found){
        echo json_encode(array('status' => true, 'message' => 'Distributor Site Url already used in this site')); 
        exit;
    }

    $verify_retailer = verify_retailers_key($retailer_key_id, $retailer_id, $distributor_url);
    $response = json_decode($verify_retailer, true);

    if ($response['insert_in'] == true) {
        $wpdb->insert( 
            $distributor_table, 
            array( 
                'retailer_id' => $retailer_id, 
                'retailer_key_id' => $retailer_key_id, 
                'distributor_url' => $distributor_url, 
            ) 
        );
    }
    
    echo $verify_retailer;
    exit;
}

add_action( 'wp_ajax_nopriv_products_categories', 'products_categories' );
add_action( 'wp_ajax_products_categories', 'products_categories' );
function products_categories() {
    // WP Globals
    global $wpdb;
    $retailer_id     = trim($_REQUEST['retailer_id']);
    $retailer_key_id = trim($_REQUEST['retailer_key_id']);
    $distributor_url = trim($_REQUEST['distributor_url']);

    $verify_retailer = verify_retailers_key($retailer_key_id, $retailer_id, $distributor_url);
    $verify_retailer_response = json_decode($verify_retailer, true);

    if ($verify_retailer_response['insert_in'] == true) {
        $products_categories = distributor_products_categories($retailer_id, $retailer_key_id, $distributor_url);
        $response = json_decode($products_categories, true);
        echo $products_categories;
    }
    
    exit;
}

add_action( 'wp_ajax_nopriv_get_category_products', 'get_category_products' );
add_action( 'wp_ajax_get_category_products', 'get_category_products' );
function get_category_products() {
    // WP Globals
    global $wpdb, $woocommerc;
    $retailer_id     = trim($_REQUEST['retailer_id']);
    $retailer_key_id = trim($_REQUEST['retailer_key_id']);
    $distributor_url = trim($_REQUEST['distributor_url']);
    $category        = $_REQUEST['category'];
    $cat_ids         = array_values($category);
    $verify_retailer = verify_retailers_key($retailer_key_id, $retailer_id, $distributor_url);
    $verify_retailer_response = json_decode($verify_retailer, true);

    if ($verify_retailer_response['insert_in'] == true) {
        $products_categories = distributor_category_products($retailer_id, $retailer_key_id, $distributor_url, $cat_ids);
        $response = json_decode($products_categories, true);
        echo $products_categories;

        /* Create Product */
        $helper = new RetailerProduct_API_Helper();
        echo $helper->add_retailer_products( $response, $retailer_id, $retailer_key_id, $distributor_url);

    }
    
    exit;
}

add_action('woocommerce_checkout_order_processed', 'wc_on_place_order');
function wc_on_place_order( $order_id ) {
    global $wpdb;

    // get order object and order details
    $order = new WC_Order( $order_id ); 

    // get product details
    $items = $order->get_items();
    //return $items;
    
    $orders_info = array();
    $order_prod_info = array();
    foreach ($items as $key => $item) {
        //returns the type (i.e. variable or simple)
        $type           = $item->get_type();

        $product_id     = $item->get_product_id();
        $product        = wc_get_product( $product_id );
        $item_quantity  = $item->get_quantity(); // Get the item quantity
        $item_total     = $item->get_total(); // Get the item line total discounted

        $_product_info = get_post_meta( $product_id, '_product_info', true);
        $distributor_pro_id = get_post_meta( $product_id, 'distributor_pro_id', true);
        $distributor_site_id = get_post_meta( $product_id, 'distributor_site_id', true);

        //a default
        $variation_id = false;

        //check if this is a variation using is_type
        $product_attribute = [];
        if( $product->is_type('variable') ) {
            $variation_id = $item->get_variation_id();

             // Get the variation attributes
            $variation_attributes = $product->get_variation_attributes();
            // Loop through each selected attributes
            foreach($variation_attributes as $attribute_taxonomy => $term_slug ){
                // Get product attribute name or taxonomy
                $taxonomy = str_replace('attribute_', '', $attribute_taxonomy );
                // The label name from the product attribute
                $attribute_name = wc_attribute_label( $taxonomy, $product );
                // The term name (or value) from this attribute
                if( taxonomy_exists($taxonomy) ) {
                    $attribute_value[$taxonomy] = get_term_by( 'slug', $term_slug, $taxonomy )->name;
                } else {
                    $attribute_value[$taxonomy] = $term_slug; // For custom product attributes
                }

                $product_attribute[$taxonomy] = $term_slug;
            }
        }
    
        $addressShipping = $order->get_address('shipping'); 
        $addressBilling = $order->get_address('billing');

        $orders_info[$distributor_site_id] = $_product_info;
        $orders_info[$distributor_site_id]['retailer_order_info'] = array( 'retailer_site_url' => site_url(), 'order_id' => $order_id, );

        $shipping_blank = 0;
        foreach($addressShipping as $keys){
            if(!empty($keys)) {
                $shipping_blank++;
            }
        }

        if($shipping_blank > 0){
            $Shipping_empty = 'false';
        }else {
            $Shipping_empty = 'true';
        }

        if ($Shipping_empty == 'false') {
            $orders_info[$distributor_site_id]['addressShipping'] = $addressShipping;
        }else{
            $orders_info[$distributor_site_id]['addressShipping'] = $addressBilling;
        }

        $orders_info[$distributor_site_id]['addressBilling'] = $addressBilling;
        $orders_info[$distributor_site_id]['products'] = [];

        $prod_obj = [];
        $prod_obj['distributor_pro_id'] = $distributor_pro_id;
        $prod_obj['distributor_site_id'] = $distributor_site_id;
        $prod_obj['product_id'] = $product_id;
        $prod_obj['item_quantity'] = $item_quantity;
        $prod_obj['item_total'] = $item_total;
        $prod_obj['product_attribute'] = $product_attribute;
    
        array_push($order_prod_info,$prod_obj);
        
    }
    
    foreach ($order_prod_info as $pi_key => $prod_info) {
        foreach ($orders_info as $oi_key => $order_info) {
            if($oi_key == $prod_info['distributor_site_id']){
                // $order_info[$pi_key] = $prod_info;
                array_push($orders_info[$oi_key]['products'], $prod_info);
            }
        }
    }

    //passing $orders_info to external api using `curl_exec`

    foreach ($orders_info as $key => $order_data) {
        if ($order_data) {
            $created_order = distributor_create_order($order_data);     

            $response = json_decode($created_order, true);
            // echo $created_order; 
        }
    }
}