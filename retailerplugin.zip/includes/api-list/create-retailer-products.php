<?php 

if (class_exists('RetailerProduct_API_Helper') != true) {
    class RetailerProduct_API_Helper {

		public function style_post_content( $content )
		{
			if( $content != "" ){
				return wpautop( $content ); 
			}
			
			return $content;
		}
		
		protected function check_for_duplicate( $product=array() )
		{
			$args = array(
			    'posts_per_page'   	=> -1,
			    'orderby'          	=> 'post_date',
			    'order'            	=> 'DESC',
			    'post_type' 		=> "product",
			    'post_status'      	=> 'publish',
			    'meta_query' => array(
			        array(
			            'key'     => 'distributor_site_id',
			            'value'   => $product['contractAddress'],
			            'compare' => '===',
			        ),
			    ),
			);
			
			$duplicate_posts = get_posts( $args );
			if( count($duplicate_posts) > 0 && isset($duplicate_posts[0]) ){
				if( isset($duplicate_posts[0]->ID) ){
					return array(
						'status' 	=> 'product_duplicate',
						'post_id'	=> $duplicate_posts[0]->ID
					);
				}
			}

			return array( 'status' => 'new_product' );
		}

		public function Generate_Featured_Image( $image_url, $post_id , $post_title, $post_content ){
		    $upload_dir = wp_upload_dir();
		    $image_data = file_get_contents($image_url);
		    $filename = basename($image_url);
		    if(wp_mkdir_p($upload_dir['path']))
		      $file = $upload_dir['path'] . '/' . $filename;
		    else
		      $file = $upload_dir['basedir'] . '/' . $filename;
		    file_put_contents($file, $image_data);

		    $wp_filetype = wp_check_filetype($filename, null );
		    $attachment = array(
		        'post_mime_type' => $wp_filetype['type'],
		        'post_title' => $post_title,
		        'post_content' => $post_content,
		        'post_status' => 'publish'
		    );
		    $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
		    require_once(ABSPATH . 'wp-admin/includes/image.php');
		    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
		    $res1= wp_update_attachment_metadata( $attach_id, $attach_data );
		    $res2= set_post_thumbnail( $post_id, $attach_id );
		}

		public function set_price($post_id, $product)
		{

			update_post_meta( $post_id, '_price', $product['price']);
			update_post_meta( $post_id, '_regular_price', $product['regular_price']);
			update_post_meta( $post_id, '_sale_price', $product['sale_price']);
			
		}

		public function add_retailer_products( $response, $retailer_id, $retailer_key_id, $distributor_url)
		{
			
		    global $wpdb;

		    $distributor_table = $wpdb->prefix.'distributor_list';
		    $distributor_query = $wpdb->prepare("SELECT * FROM $distributor_table WHERE retailer_id = $retailer_id AND retailer_key_id = '$retailer_key_id'");
		    $distributors = $wpdb->get_results($distributor_query);
		    $distributors_id = $distributors[0]->id;

			$checkDuplicate = true;
			$insertNew = true;
			$postStatus = "publish";
			$callback= null;

		    $products = $response['category_products']['products'];

			foreach ($products as $key => $product) {

				$args = array(
				    'posts_per_page'   	=> -1,
				    'orderby'          	=> 'post_date',
				    'order'            	=> 'DESC',
				    'post_type' 		=> "product",
				    'post_status'      	=> 'publish',
				    'meta_query' => array(
				    	'relation'	  => 'AND',
				        array(
				            'key'     => 'distributor_site_id',
				            'value'   => $distributors_id,
				            'compare' => '===',
				        ),
				        array(
				            'key'     => 'distributor_pro_id',
				            'value'   => $product['id'],
				            'compare' => '===',
				        ),
				    ),
				);
					
				$duplicate_posts = get_posts( $args );

				if($duplicate_posts){
					
				}else{

					$post = [];
					$post_id = 0;
					if($insertNew) {
						$post = array(
							'post_author' => get_current_user_id(),
							'post_content' => $product['description'] === null ? '' : $this->style_post_content($product['description']),
							'post_status' => $postStatus,
							'post_title' => !empty($product['name']) ? $product['name'] : '',
							'post_type' => "product",
							'tax_input' => $custom_tax,
						);

						// create the post 
						$post_id = wp_insert_post( $post );

			            update_post_meta($post_id, '_stock_status', $product['product_instock']);	            
			           	update_post_meta($post_id, '_stock', $product['stock_quantity']);	           
			            update_post_meta($post_id, '_manage_stock', $product['manage_stock']);
			           	update_post_meta($post_id, '_stock_status', $product['stock_status']);
			            
			            update_post_meta($post_id, '_backorders', $product['backorders']);
			           	update_post_meta($post_id, '_sold_individually', $product['sold_individually']);

					}

					if ($product['categories']) {
						foreach ($product['categories'] as $key => $category) {
							$taxonomy = 'product_cat';
							$append = true ;// true means it will add the cateogry beside already set categories. false will overwrite

						    $category_name = $category['name'];

						    //get the category to check if exists
							$cat  = get_term_by('name', $category_name , $taxonomy);

							//check existence
							if($cat == false){
							    //cateogry not exist create it 
							    $cat = wp_insert_term($category_name, $taxonomy);
							    //category id of inserted cat
							    $cat_id = $cat['term_id'] ;
							}else{
							    //category already exists let's get it's id
							    $cat_id = $cat->term_id ;
							}

							//setting post category 
							$res = wp_set_post_terms($post_id, array($cat_id),$taxonomy ,$append);
						}
					}

					if ($product['tags']) {
						foreach ($product['tags'] as $key => $tag) {
							$taxonomy = 'product_tag';
							$append = true ;// true means it will add the cateogry beside already set tags. false will overwrite

						    $tag_name = $tag['name'];

						    //get the tag to check if exists
							$tag_t  = get_term_by('name', $tag_name , $taxonomy);

							//check existence
							if($tag_t == false){
							    //cateogry not exist create it 
							    $tag_t = wp_insert_term($tag_name, $taxonomy);
							    //category id of inserted cat
							    $tag_t_id = $tag_t['term_id'] ;
							}else{
							    //category already exists let's get it's id
							    $tag_t_id = $tag_t->term_id ;
							}

							//setting post tag 
							$res = wp_set_post_terms($post_id, array($tag_t_id),$taxonomy ,$append);
						}
					}

					$terms = get_the_terms(  $post_id, 'product_cat' );

		            $categories = array();
		            foreach($terms as $key => $trm) {
		                $cat_data = array();
		                $cat_data['term_id'] = $trm->term_id;
		                $cat_data['name'] = $trm->name;
		                $cat_data['slug'] = $trm->slug;
		                $cat_data['image_url'] = '';
		                $categories[] = $cat_data;
		            }
					$terms_ids = array_column($terms, 'term_id');

					$retailer_cat = $categories;
					$distributor_cat = $product['categories'];

					$distributor_info_products_logs = $wpdb->prefix.'distributor_info_products_logs';

					if ($post_id) {
				        $wpdb->insert( 
				            $distributor_info_products_logs, 
				            array( 
				                'distributor_site_id' => $distributors_id, 
				                'retailer_pro_id' => $post_id, 
				                'distributor_pro_id' => $product['id'], 
				                'retailer_cat' => serialize($retailer_cat), 
				                'distributor_cat' => serialize($distributor_cat), 
				                'distributor_site_url' => $distributor_url, 
				            ) 
				        );
				    }

					update_post_meta( $post_id, 'distributor_site_id', $distributors_id );
					update_post_meta( $post_id, 'distributor_pro_id', $product['id'] );

					$_product_info = array( 
						'retailer_id' => $retailer_id,
						'retailer_key_id' => $retailer_key_id,
						'distributor_url' => $distributor_url
					);

					update_post_meta( $post_id, '_product_info', $_product_info);

					self::Generate_Featured_Image( $product['image_url'], $post_id, $product['name'], $product['description'] );
					self::set_price($post_id, $product);

					if($callback !== null)
						$callback($post_id, $product);

				}
			}
		}  
	}
}