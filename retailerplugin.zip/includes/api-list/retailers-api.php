<?php 

/* Retailers Api's */

function verify_retailers_key($retailer_key_id, $retailer_id, $distributor_url) {

  $curl = curl_init();

  curl_setopt_array($curl, array(
    CURLOPT_URL => $distributor_url.'/wp-json/api/retailer/verify_retailer',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS =>'{
        "retailer_key_id": "'.$retailer_key_id.'",
        "retailer_id": "'.$retailer_id.'"
    }',
    CURLOPT_HTTPHEADER => array(
      'Content-Type: application/json'
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);
  return $response;

}

function distributor_products_categories($retailer_id, $retailer_key_id, $distributor_url) {

  $curl = curl_init();

  curl_setopt_array($curl, array(
    CURLOPT_URL => $distributor_url.'/wp-json/api/products/products_categories',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS =>'{
        "per_page": "all",
        "retailer_key_id": "'.$retailer_key_id.'",
        "retailer_id": "'.$retailer_id.'"
    }',
    CURLOPT_HTTPHEADER => array(
      'Content-Type: application/json'
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);
  return $response;

}

function distributor_category_products($retailer_id, $retailer_key_id, $distributor_url, $category) {

  $curl = curl_init();

  $parameters = array("category" =>$category,"retailer_key_id"=>$retailer_key_id,"retailer_id"=>$retailer_id);

  curl_setopt_array($curl, array(
    CURLOPT_URL => $distributor_url.'/wp-json/api/products/category_products',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => json_encode($parameters),
    CURLOPT_HTTPHEADER => array(
      'Content-Type: application/json'
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);
  return $response;

}

function distributor_create_order($order_data) {
     
  $verify_retailer = verify_retailers_key($order_data['retailer_key_id'], $order_data['retailer_id'], $order_data['distributor_url']);
  $verify_retailer_response = json_decode($verify_retailer, true);

  if ($verify_retailer_response['insert_in'] == true) {    
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => $order_data['distributor_url'].'/wp-json/api/process/create_order',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => json_encode($order_data),
      CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json'
      ),
    ));
    $response = curl_exec($curl);

    curl_close($curl);
    return $response;
  }
}