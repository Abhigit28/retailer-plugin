<?php 

/**
 * @package Distributors\Classes
 * @version 1.0.0
 **/


/**
 * Distributors class.
**/

class Distributors{

	protected $namespace = 'api/distributor';

	public function __construct(){
		add_action('rest_api_init', array($this, 'JsondistributorApi'));
	}

	public function JsondistributorApi(){
		register_rest_route($this->namespace, '/verify_distributor', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'verify_distributor']
        ]);
	}

	public function verify_distributor($request) {
        $parameters = $request->get_json_params();
        extract($parameters);

        if(empty($retailer_key_id)){
			$response['status'] = false;
			$response['message'] = "Please insert Retailer Key";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		if(empty($retailer_id)){
			$response['status'] = false;
			$response['message'] = "Please insert Retailer id";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		if(empty($distributor_site_url)){
			$response['status'] = false;
			$response['message'] = "Please insert distributor site url";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		global $wpdb;

	    $distributor_table = $wpdb->prefix.'distributor_list';
	    $distributor_query = $wpdb->prepare("SELECT * FROM $distributor_table WHERE retailer_id = $retailer_id AND retailer_key_id = '$retailer_key_id' AND distributor_url = '$distributor_site_url'");

	    $distributors = $wpdb->get_results($distributor_query);

		if ($distributors) {
			$response['status'] = true;
			$response['insert_in'] = true;
			$response['message'] = "Retailer Key Verified";
			$response['data'] = array( 
				'retailer_key' => $retailer_key_id,
				'retailer_id' => $retailer_id
			);

		}else{
			$response['status'] = true;
			$response['message'] = "Retailer id not found";
			$response['data'] = $retailer_id;
		}
		
		return new WP_REST_Response($response, 200);

	}

}

$Distributors = new Distributors();