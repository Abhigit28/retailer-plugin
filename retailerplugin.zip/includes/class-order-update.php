<?php

/**
 * Order update
 *
 * @package Retailer\Classes
 * @version 1.0.0
 */


/**
 * OrderUpdate class.
 */

class OrderUpdate {

	/**
	 * Route base.
	 *
	 * @var string
	 */
    protected $namespace = 'api/orders';

	public function __construct() {

        add_action('rest_api_init', array($this, 'JsonOrderApi'));

    }

	/**
	 * Register the routes for order.
	 */
	public function JsonOrderApi() {

		register_rest_route($this->namespace, 'update_order', array(
			'methods' => WP_REST_Server::CREATABLE, 
			'callback' => array($this, 'update_order')
		));

	}

	/**
	 * update order from the REST request.
	 *
	 * @param array $request Request array.
	 * @return array
	 */
	public function update_order($request) {

		$parameters = $request->get_json_params();

		extract($parameters);

        if(empty($retailer_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'retailer_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		if(empty($retailer_key_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'retailer_key_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		if(empty($order_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'order_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		global $woocommerce, $wpdb;

		if($products){ 

			$order = new WC_Order( $order_id );

			$items = $order->get_items(); 
			foreach ( $items as $line_item_id => $item ) {
				foreach ($products as $key => $product) {
					if( $item['product_id'] == $product['product_id'] ){
						// wc_update_order_item_meta( $line_item_id, ucfirst(str_replace('_',' ', 'order_status')), ucfirst(str_replace('-',' ',$order_status)) );
						wc_update_order_item_meta( $line_item_id, 'order_status', ucfirst(str_replace('-',' ',$order_status)) );
					}
				}
			}

			$response['status'] = "Success";
			
			$response['order'] = $order->get_id();

			$response['data'] = $products;

			$response['message'] = "Order Sucessfully updated.";

			return new WP_REST_Response($response, 200);

		}else{

			$response['status'] = "error";

			$response['message'] =  "items not found.";

			return new WP_REST_Response($response, 200);

		}
	}
}

$OrderUpdate = new OrderUpdate();