<?php

/**
 * Product update
 *
 * @package Retailer\Classes
 * @version 1.0.0
 */

// Define a constant to use with html emails
define("HTML_EMAIL_HEADERS", array('Content-Type: text/html; charset=UTF-8'));

/**
 * ProductUpdate class.
 */

class ProductUpdate {

	/**
	 * Route base.
	 *
	 * @var string
	 */
    protected $namespace = 'api/product';

	public function __construct() {

        add_action('rest_api_init', array($this, 'JsonProductApi'));

    }

	/**
	 * Register the routes for order.
	 */
	public function JsonProductApi() {

		register_rest_route($this->namespace, 'update_product', array(
			'methods' => WP_REST_Server::CREATABLE, 
			'callback' => array($this, 'update_product')
		));

	}

	/**
	 * update order from the REST request.
	 *
	 * @param array $request Request array.
	 * @return array
	 */
	public function update_product($request) {

		$parameters = $request->get_json_params();

		extract($parameters);

        if(empty($retailer_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'retailer_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		if(empty($retailer_key_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'retailer_key_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		if(empty($distributor_product_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'distributor_product_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		global $woocommerce, $wpdb;

		$args = array(
		    'post_type' 		=> "product",
		    'meta_query' => array(
		    	'relation'	  => 'AND',
		        array(
		            'key'     => 'distributor_pro_id',
		            'value'   => $distributor_product_id,
		            'compare' => '===',
		        ),
		    ),
		);
			
		$post = get_posts( $args );

		$product_id = $post[0]->ID;
		$product_meta = get_post_meta($product_id);
		$_product_info = get_post_meta($product_id, '_product_info', true);

		if ($product_id && $retailer_key_id == $_product_info['retailer_key_id']) {
			if($product_data){

				$post_data = [
					'ID' => $product_id,
					'post_title' => $product_data['product_name'],
					'post_content' => $product_data['product_description'],
					'post_status' => $product_data['product_status'],
				];
				$post_id = wp_update_post($post_data, true);

		        $admin_email = get_option( 'admin_email' );
		        if ( isset($_SERVER['SERVER_NAME']) && empty($admin_email) ) {
		            $admin_email = 'support@' . sanitize_text_field(wp_unslash($_SERVER['SERVER_NAME']));
		        }

		        // format the message
		        $message = $this->update_retailer_products_admin_message($admin_email, $product_id, $product_data);
		        $subject = sprintf( __( '[%s] Product updated', 'distributor' ), get_option( 'blogname' ) );

		        $headers = 'Your Product #'.$product_id.' is updated';

		        $this->update_product_send_email_wc_style($admin_email, $subject, $headers, $message);

	            //set Product Category
				// Overwrite any existing term
				if (!empty($product_data['categories'])) {
					wp_set_object_terms( $product_id, $product_data['categories'], 'product_cat' );
				}

				//set Product tag
				// Overwrite any existing term
				wp_set_object_terms( $product_id, $product_data['tags'], 'product_tag' );

	            //set product type
	            wp_set_object_terms($product_id, $product_data['product_type'], 'product_type');
	            
	            update_post_meta($product_id, '_stock_status', $product_data['product_instock']);	            
	           	update_post_meta($product_id, '_stock', $product_data['product_qty']);	           
	           	update_post_meta($product_id, '_price', $product_data['product_price']);	           
	           	update_post_meta($product_id, '_regular_price', $product_data['product_regular_price']);	           
	           	update_post_meta($product_id, '_sale_price', $product_data['product_sale_price']);	           
	            update_post_meta($product_id, '_manage_stock', $product_data['manage_stock']);
	           	update_post_meta($product_id, '_stock_status', $product_data['stock_status']);
	            
	            update_post_meta($product_id, '_backorders', $product_data['backorders']);
	           	update_post_meta($product_id, '_sold_individually', $product_data['sold_individually']);

				$response['status'] = "Success";

				$response['product_id'] = $product_id;
				
				$response['product_data'] = $product_data;

				$response['message'] = "Product Sucessfully updated.";

				return new WP_REST_Response($response, 200);

			}else{

				$response['status'] = "error";

				$response['message'] =  "product not found.";

				return new WP_REST_Response($response, 200);

			}
		}
	}

	// @email - Email address of the reciever
	// @subject - Subject of the email
	// @heading - Heading to place inside of the woocommerce template
	// @message - Body content (can be HTML)
	public function update_product_send_email_wc_style($admin_email, $subject, $headers, $message) {

	  // Get woocommerce mailer from instance
	  $mailer = WC()->mailer();

	  // Wrap message using woocommerce html admin_email template
	  $wrapped_message = $mailer->wrap_message($headers, $message);

	  // Create new WC_Email instance
	  $wc_email = new WC_Email;

	  // Style the wrapped message with woocommerce inline styles
	  $html_message = $wc_email->style_inline($wrapped_message);

	  // Send the admin_email using wordpress mail function
	  $mailer->send( $admin_email, $subject, $html_message, HTML_EMAIL_HEADERS );

	}

	/**
	 * The default email message that will be sent to users as they are approved.
	 *
	 * @return string
	 */
	public function update_retailer_products_admin_message($admin_email, $product_id, $product_data) {

		global $wpdb, $woocommerce;

		// $message .= sprintf( __( 'Your Product %s is updated.', 'retailer' ), $product_id ) . "\r\n\r\n";

		$distributor_url = get_post_meta( $product_id, '_product_info', true)['distributor_url'];

		$message .= __( 'Product Details.', 'retailer' ). "\r\n\r\n";

		$message .=  '<table border="1" style="width:100%; margin-bottom:20px">';

		$message .= '<tr style="width:100%"><th style="width:30%">Distributor url:</th><td style="width:70%">'.$distributor_url.'</td></tr>';

		foreach ($product_data as $key => $product_value) {
			if ($product_value && $key == 'categories') {
				$message .= '<tr style="width:100%"><th style="width:30%">'.ucfirst(str_replace('_', ' ', $key)).':</th><td style="width:70%">'.implode(', ',$product_value).'</td></tr>';
			}elseif ($product_value && $key == 'tags') {
				$message .= '<tr style="width:100%"><th style="width:30%">'.ucfirst(str_replace('_', ' ', $key)).':</th><td style="width:70%">'.implode(', ',$product_value).'</td></tr>';
			}elseif($product_value){
				$message .= '<tr style="width:100%"><th style="width:30%">'.ucfirst(str_replace('_', ' ', $key)).':</th><td style="width:70%">'.$product_value.'</td></tr>';
			}
		}

		$message .= '</table>';

		// $message .= __( 'You can check your products area at: <a href="'.admin_url('post.php?post='.$product_id.'&action=edit').'" target="_blank">Edit Product</a>.', 'retailer' ) . "\r\n\r\n";

		$message .= __("Thank You", "retailer");

		return $message;
	}
}

$ProductUpdate = new ProductUpdate();