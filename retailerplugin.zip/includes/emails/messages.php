<?php 

/**
 * The default email message that will be sent to users as they are approved.
 *
 * @return string
 */
function update_retailer_products_admin_message($admin_email, $product_id, $product_data) {

	global $wpdb, $woocommerce;

	// $message .= sprintf( __( 'Your Product %s is updated.', 'retailer' ), $product_id ) . "\r\n\r\n";

	$distributor_url = get_post_meta( $product_id, '_product_info', true)['distributor_url'];

	$message .= __( 'Product Details.', 'retailer' ). "\r\n\r\n";

	$message .=  '<table border="1" style="width:100%; margin-bottom:20px">';

	$message .= '<tr style="width:100%"><th style="width:30%">Distributor url:</th><td style="width:70%">'.$distributor_url.'</td></tr>';

	foreach ($product_data as $key => $product_value) {
		if ($product_value && $key == 'categories') {
			$message .= '<tr style="width:100%"><th style="width:30%">'.ucfirst(str_replace('_', ' ', $key)).':</th><td style="width:70%">'.implode(', ',$product_value).'</td></tr>';
		}elseif($product_value){
			$message .= '<tr style="width:100%"><th style="width:30%">'.ucfirst(str_replace('_', ' ', $key)).':</th><td style="width:70%">'.$product_value.'</td></tr>';
		}
	}

	$message .= '</table>';

	// $message .= __( 'You can check your products area at: <a href="'.admin_url('post.php?post='.$product_id.'&action=edit').'" target="_blank">Edit Product</a>.', 'retailer' ) . "\r\n\r\n";

	$message .= __("Thank You", "retailer");

	return $message;
}
