<?php
/**
* Plugin Name: Retailer Plugin
* Plugin URI: https://eoxysit.com/
* Description: Retailer Plugin for WooCommerce.
* Version: 1.0.0
* Author: Eoxys IT Dev
* Author URI: https://eoxysit.com/
* Text Domain: retailer
**/


if ( ! defined( 'ABSPATH' ) ) {
    die('security by preventing any direct access to your plugin file');
}

require_once ABSPATH . 'wp-admin/includes/plugin.php';
// @include_once 'includes/emails/messages.php';
// @include_once 'includes/emails/update-product-email.php';
@include_once 'includes/class-distributor.php';
@include_once 'includes/class-product-update.php';
@include_once 'includes/class-order-update.php';
@include_once 'includes/api-list/retailers-api.php';
@include_once 'includes/api-list/create-retailer-products.php';
@include_once 'includes/ajax/functions-ajax.php';
@include_once 'retailer-tab/single-distributor-details.php';

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) or is_plugin_active_for_network( 'woocommerce/woocommerce.php' ) ) {

        add_action( 'wp_enqueue_scripts', 'retailer_my_enqueue' );
        add_action( 'admin_enqueue_scripts', 'retailer_my_enqueue' );
        function retailer_my_enqueue($hook) {
            wp_enqueue_style( 'retailer-style', plugins_url( '/assets/css/retailer.css', __FILE__ ) );
            wp_enqueue_style( 'retailer-styles', plugins_url( '/assets/css/jquery.multiselect.css', __FILE__ ) );
            wp_enqueue_script( 'retailer-scripts', plugins_url( '/assets/js/jquery.multiselect.js', __FILE__ ), array('jquery') );
            wp_enqueue_script( 'retailer-script', plugins_url( '/assets/js/retailer.js', __FILE__ ), array('jquery') );
            wp_localize_script( 'ajax-script', 'my_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

            wp_enqueue_style( 'retailer-dataTables-style', plugins_url( '/assets/lib/dataTables/jquery.dataTables.min.css', __FILE__ ) );
            wp_enqueue_script( 'retailer-dataTables-script', plugins_url( '/assets/lib/dataTables/jquery.dataTables.min.js', __FILE__ ), array('jquery') );
        }

        // add parent category to site menu
        function retailer_add_settings_page() {
            if ( !empty ( $GLOBALS['admin_page_hooks']['retailer_plugins'] ) ) {
                return;
            }

            add_menu_page(
                esc_html__("Retailer", "retailer"), 
                esc_html__("Retailer", "retailer"), 
                "NULL", 
                "retailer_plugins", 
                "sc_menu_page", 
                "dashicons-store", 
                50,
            );
            //call register settings function
            add_action( 'admin_init', 'register_retailer_plugins_settings' );
        }

        add_action( 'admin_menu', 'retailer_add_settings_page' );

        // add child category to parent to site menu
        function retailer_add_submenu_pages() {
            add_submenu_page(
                "retailer_plugins",
                esc_html__("Retailer Plugin", "retailer"),
                esc_html__("Retailer Plugin", "retailer"), 
                "manage_options",
                "retailer-page",
                "retailer_render_plugin_settings_page"
            );
        }
        add_action( 'admin_menu', 'retailer_add_submenu_pages' );

        function register_retailer_plugins_settings() {
            //register our settings
            register_setting( 'retailer-plugin-genral-tab', 'retailer_key_id' );
            register_setting( 'retailer-plugin-setting-tab', 'distributor_id' );
            register_setting( 'retailer-plugin-setting-tab', 'distributor_url' );
        }

        // render form
        function retailer_render_plugin_settings_page() {
            // check user capabilities
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            //Get the active tab from the $_GET param
            $general_tab = null;
            $tab = isset($_GET['tab']) ? $_GET['tab'] : $general_tab;
            ?>
          
            <!-- Our admin page content should all be inside .wrap -->
                <div class="retailer-page-layout__header">
                    <h1 class="retailer-layout__header-heading"><?php echo esc_html( get_admin_page_title() ); ?></h1>
                </div>
                <div class="wrap" style="margin-top: 80px;">
                    <!-- Print the page title -->
                    <!-- Here are our tabs -->
                    <?php settings_errors(); ?> 
                    <nav class="nav-tab-wrapper">
                        <a href="?page=retailer-page" class="nav-tab <?php if($tab===null):?>nav-tab-active<?php endif; ?>">Settings</a>
                        <!-- <a href="?page=retailer-page&tab=settings" class="nav-tab <?php //if($tab==='settings'):?>nav-tab-active<?php //endif; ?>">Settings</a> -->
                        <a href="?page=retailer-page&tab=distributor-list" class="nav-tab <?php if($tab==='distributor-list'):?>nav-tab-active<?php endif; ?>">Connected Distributor List</a>
                        <a href="?page=retailer-page&tab=import-log-list" class="nav-tab <?php if($tab==='import-log-list'):?>nav-tab-active<?php endif; ?>">Products Import Logs</a>
                    </nav>

                    <div class="tab-content">
                    <?php switch($tab) :
                        case 'settings': ?>
                            <?php @include_once 'retailer-tab/general-tab.php';
                            break;
                        case 'distributor-list': ?>
                            <?php @include_once 'retailer-tab/distributor-list-tab.php';
                            break;
                        case 'import-log-list': ?>
                            <?php @include_once 'retailer-tab/import-log-tab.php';
                            break;
                        default:?>
                            <?php @include_once 'retailer-tab/settings-tab.php';
                            break;
                        endswitch; ?>
                    </div>
              </div>
            <?php
        }

        register_activation_hook( __FILE__, 'create_plugin_database_table' );

        // Initialize DB Tables
        function create_plugin_database_table() {

            // WP Globals
            global $wpdb;

            $distributor_list = $wpdb->prefix.'distributor_list';

            // Create Table if not exist
            if( $wpdb->get_var( "show tables like '$distributor_list'" ) != $distributor_list ) {
                $charset = $wpdb->get_charset_collate();
                $charset_collate = $wpdb->get_charset_collate();
                // Query - Create Table
                $sql = "CREATE TABLE $distributor_list (";
                $sql .= " id int(11) NOT NULL auto_increment, ";
                $sql .= " retailer_id varchar(500) NOT NULL, ";
                $sql .= " retailer_key_id varchar(500) NOT NULL, ";
                $sql .= " distributor_url varchar(500), ";
                $sql .= " created_date DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL, ";
                $sql .= " PRIMARY KEY (id) ";
                $sql .= ") ".$charset_collate.";";

                // Include Upgrade Script
                require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
            
                // Create Table
                dbDelta( $sql );
            }

            $distributor_info_products_logs = $wpdb->prefix.'distributor_info_products_logs';
     
            // Create Table if not exist
            if( $wpdb->get_var( "show tables like '$distributor_info_products_logs'" ) != $distributor_info_products_logs ) {
                $charset = $wpdb->get_charset_collate();
                $charset_collate = $wpdb->get_charset_collate();
                // Query - Create Table
                $sql = "CREATE TABLE $distributor_info_products_logs (";
                $sql .= " id int(11) NOT NULL auto_increment, ";
                $sql .= " distributor_site_id varchar(500) NOT NULL, ";
                $sql .= " retailer_pro_id varchar(500) NOT NULL, ";
                $sql .= " distributor_pro_id varchar(500), ";
                $sql .= " retailer_cat longtext, ";
                $sql .= " distributor_cat longtext, ";
                $sql .= " distributor_site_url varchar(500), ";
                $sql .= " date DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL, ";
                $sql .= " PRIMARY KEY (id) ";
                $sql .= ") ".$charset_collate.";";

                // Include Upgrade Script
                require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
            
                // Create Table
                dbDelta( $sql );
            }

        }


}else{
    add_action( 'admin_notices', 'retailer_auction_error_notice' );
    function retailer_auction_error_notice() {
        global $current_screen;

        if ( $current_screen->parent_base == 'plugins' ) {
            echo '<div class="error"><p>'.esc_html__('retailer plugin requires WooCommerce to be activated in order to work. Please install and activate', 'retailer').' <a href="' . admin_url( 'plugin-install.php?tab=search&type=term&s=WooCommerce' ) . '" target="_blank">'.esc_html__('WooCommerce', 'retailer').'</a> '.esc_html__('first', 'retailer').'</p></div>';
        }
    }
}

function retailer_is_dokan_activate(){
    if (in_array( 'dokan-lite/dokan.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) )) {
        return true;
    }else{
        return false;
    }
}
function retailer_is_wcfm_activate(){
    if(in_array( 'wc-multivendor-marketplace/wc-multivendor-marketplace.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) )) {
        return true;
    }else{
        return false;
    }
}