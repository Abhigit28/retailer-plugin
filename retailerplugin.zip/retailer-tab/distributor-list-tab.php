<?php  
    if ($_GET['action'] == 'distributor_data' && $_GET['retailer_key_id']) { ?>

        <h3 class="title">Distributor Details</h3>

    <?php 

        global $wpdb;
        $retailer_key_id = $_GET['retailer_key_id'];
        $retailer_id = $_GET['retailer_id'];

        single_distributor_details($retailer_key_id, $retailer_id);

    }else{ ?>
        <h3 class="title">Distributor Lists</h3>
        <section id="distributor_list">
            <?php
                // WP_List_Table is not loaded automatically so we need to load it in our application
                if( ! class_exists( 'WP_List_Table' ) ) {
                    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
                }

                class Distributors_List extends WP_List_Table {

                    public function __construct() {
                        parent::__construct( array(
                        'singular' => 'distributor',
                        'plural' => 'distributors',
                        'ajax' => false
                        ));
                        $this->prepare_items();
                        $this->display();
                    }

                    function get_columns() {
                        $columns = array(
                            'site_id' => __( 'Id', 'retailer' ),
                            'retailer_id' => __( 'Retailer Id', 'retailer' ),
                            'retailer_key_id' => __( 'Key Id', 'retailer' ),
                            'distributor_url' => __( 'Distributor Site Url', 'retailer' ),
                            'actions' => __( 'Actions', 'retailer' ),
                        );
                        return $columns;
                    }

                    // function get_sortable_columns() {
                    //     return $sortable = array(
                    //         'retailer_id'      => array('retailer_id',false),
                    //         'retailer_key_id'  => array('retailer_key_id',false)
                    //     );
                    // }

                    function no_items() {
                      _e('No distributors to display', 'retailer');
                    }

                    function prepare_items() {

                        global $wpdb, $_wp_column_headers;

                        $siteid = get_current_blog_id();
                        $screen = get_current_screen();
                        $columns = $this->get_columns();
                        $hidden = array();
                        $sortable = $this->get_sortable_columns();
                        $this->_column_headers = array( $columns, $hidden, $sortable );
                        $distributor_table = $wpdb->prefix.'distributor_list';
                        $distributor_query = $wpdb->prepare("SELECT * FROM $distributor_table");

                        $total_distributors = $wpdb->get_results($distributor_query);
                        $total_distributors = $wpdb->query( $distributor_query );
                        $perpage = 15;
                        // Which page is this?
                        $paged = ! empty( $_GET['paged'] ) ? $_GET['paged'] : '';
                        // Page Number
                        if ( empty( $paged ) || ! is_numeric( $paged ) || $paged <= 0 ) {
                            $paged = 1;
                        }
                        // How many pages do we have in total?
                        $totalpages = ceil( $total_distributors / $perpage );
                        // adjust the query to take pagination into account
                        if ( ! empty( $paged ) && ! empty( $perpage ) ) {
                            $offset = ( $paged - 1 ) * $perpage;
                            $distributor_query .= ' LIMIT ' . (int) $offset . ',' . (int) $perpage;
                        }

                        $this->set_pagination_args(
                            array(
                                'total_items' => $total_distributors,
                                'total_pages' => $totalpages,
                                'per_page' => $perpage,
                            )
                        );
                        // The pagination links are automatically built according to those parameters

                        $_wp_column_headers[ $screen->id ] = $columns;
                        $this->items = $wpdb->get_results( $distributor_query );

                    }

                    function column_default( $item, $column_name) {
                        global $post, $wp_list_table, $wpdb;

                        switch($column_name) {
                            case 'site_id':
                            return $item->id;
                            break;
                            case 'retailer_id':
                            return '<a href="/wp-admin/admin.php?page=retailer-page&tab=distributor-list&action=distributor_data&retailer_id='.$item->retailer_id.'&retailer_key_id='.$item->retailer_key_id.'"><strong>#'.$item->retailer_id.'</strong></a>';
                            break;
                            case 'retailer_key_id':
                            return $item->retailer_key_id;
                            break;
                            case 'distributor_url':
                            return $item->distributor_url;
                            break;
                            case 'actions':
                            return '<a href="/wp-admin/admin.php?page=retailer-page&tab=distributor-list&action=distributor_data&retailer_id='.$item->retailer_id.'&retailer_key_id='.$item->retailer_key_id.'"><strong>View</strong></a>';
                            break;
                        }
                    }
                }

                $retailers = new Distributors_List(); 

            ?>
        </section>
    <?php } ?>