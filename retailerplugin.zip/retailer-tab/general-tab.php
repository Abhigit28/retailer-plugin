<h3 class="title">Retailer Details</h3>
<form method="post" action="options.php">
    <?php settings_fields('retailer-plugin-genral-tab'); ?>
    <div id="retailer_flat_type">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Retailer Key Id</th>
                <td>
                    <input type="text" id="retailer_key_id" name="retailer_key_id" value="<?php echo get_option( 'retailer_key_id' ); ?>">
                    <p class="description">This is Key id.</p>
                </td>
            </tr>
        </table>
    </div>      
    <?php submit_button(); ?>
</form>
  