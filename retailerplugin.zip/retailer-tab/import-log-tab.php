<h3 class="title">Products Import Logs Details</h3>
<section id="import_product_logs">
    <?php

    // WP_List_Table is not loaded automatically so we need to load it in our application
    if( ! class_exists( 'WP_List_Table' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
    }

    class Products_Import_Logs extends WP_List_Table {

        public function __construct() {

            parent::__construct( array(
                'singular' => 'product_log',
                'plural' => 'product_logs',
                'ajax' => false
            ));

            $this->prepare_items();
            $this->display();
        }

        function get_columns() {
            $columns = array(
                'id' => __( 'Id', 'retailer' ),
                'distributor_site_url' => __( 'Site Url', 'retailer' ),
                'retailer_pro_id' => __( 'Product Id', 'retailer' ),
                'distributor_pro_id' => __( 'Distributor product Id', 'retailer' ),
                'retailer_cat' => __( 'Category(Id,Name)', 'retailer' ),
                'distributor_cat' => __( 'Distributor Category(Id,Name)', 'retailer' ),
                'date' => __( 'Date', 'retailer' ),
            );
            return $columns;
        }

        function no_items() {
          _e('No logs found', 'retailer');
        }

        function prepare_items() {

            global $wpdb, $_wp_column_headers;

            $siteid = get_current_blog_id();
            $screen = get_current_screen();
            $columns = $this->get_columns();
            $hidden = array();
            $sortable = $this->get_sortable_columns();
            $this->_column_headers = array( $columns, $hidden, $sortable );

            $perpage = 20;
            // Which page is this?
            $paged = ! empty( $_GET['paged'] ) ? $_GET['paged'] : '';
            // Page Number
            if ( empty( $paged ) || ! is_numeric( $paged ) || $paged <= 0 ) {
                $paged = 1;
            }

            $distributor_info_products_logs = $wpdb->prefix.'distributor_info_products_logs';
            $products_logs_query = $wpdb->prepare("SELECT * FROM $distributor_info_products_logs ORDER BY id ASC");

            $total_products_logs = $wpdb->get_results($products_logs_query);
            $total_products_logs = $wpdb->query( $products_logs_query );

            // How many pages do we have in total?
            $totalpages = ceil( $total_products_logs / $perpage );
            // adjust the query to take pagination into account
            if ( ! empty( $paged ) && ! empty( $perpage ) ) {
                $offset = ( $paged - 1 ) * $perpage;
                $products_logs_query .= ' LIMIT ' . (int) $offset . ',' . (int) $perpage;
            }

            // $this->set_pagination_args(
            //     array(
            //         'total_items' => $total_products_logs,
            //         'total_pages' => $totalpages,
            //         'per_page' => $perpage,
            //     )
            // );
            // The pagination links are automatically built according to those parameters

            $_wp_column_headers[ $screen->id ] = $columns;
            $this->items = $wpdb->get_results( $products_logs_query );

        }

        function column_default( $item, $column_name) {
            global $post, $wp_list_table, $wpdb;


            $retailer_cats       = unserialize($item->retailer_cat);
            $distributor_cats    = unserialize($item->distributor_cat);

            $retailer_cat_name = [];
            $retailer_cat_id = [];
            foreach ($retailer_cats as $key => $retailer_cat) {
                $retailer_cat_name[$retailer_cat['term_id']] = $retailer_cat['name'];
                $retailer_cat_id[$retailer_cat['name']]      = $retailer_cat['term_id'];
            }
            $r_cat_id = implode(', ', $retailer_cat_id);
            $r_cat_name = implode(', ', $retailer_cat_name);

            $retailer_cat_list = 'ID: ('.$r_cat_id.')';
            $retailer_cat_list .= '<br>';
            $retailer_cat_list .= 'Name: ('.$r_cat_name.')';

            $distributor_cat_name = [];
            $distributor_cat_id = [];
            foreach ($distributor_cats as $key => $distributor_cat) {
                $distributor_cat_name[$distributor_cat['term_id']] = $distributor_cat['name'];
                $distributor_cat_id[$distributor_cat['name']]      = $distributor_cat['term_id'];
            }
            $d_cat_id = implode(', ', $distributor_cat_id);
            $d_cat_name = implode(', ', $distributor_cat_name);

            $distributor_cat_list = 'ID: ('.$d_cat_id.')';
            $distributor_cat_list .= '<br>';
            $distributor_cat_list .= 'Name: ('.$d_cat_name.')';

            // echo "<pre>";
            // print_r($distributor_cat_list);
            // echo "</pre>";
            // exit;

            switch($column_name) {
                case 'id':
                return $item->id;
                break;
                case 'distributor_site_url':
                return $item->distributor_site_url;
                break;
                case 'retailer_pro_id':
                return $item->retailer_pro_id;
                break;
                case 'distributor_pro_id':
                return $item->distributor_pro_id;
                break;
                case 'retailer_cat':
                return $retailer_cat_list;
                break;
                case 'distributor_cat':
                return $distributor_cat_list;
                break;
                case 'date':
                return $item->date;
                break;
            }
        }
    }

    $Products_Import_Logs = new Products_Import_Logs(); 

?>
</section>