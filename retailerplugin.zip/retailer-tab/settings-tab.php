<h3 class="title">Retailer Distributor Details</h3>
<section id="api_key_section">
    <div id="retailer_distributor">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Retailer Id</th>
                <td><input type="text" id="retailer_id" name="retailer_id" style="width: 400px;" value=""></td>
            </tr>
            <tr valign="top">
                <th scope="row">Retailer Key Id</th>
                <td><input type="text" id="retailer_key_id" name="retailer_key_id" style="width: 400px;" value=""></td>
            </tr>
            <tr valign="top">
                <th scope="row">Distributor Site Url</th>
                <td>
                    <input type="text" id="distributor_url" name="distributor_url" style="width: 400px;" value="">
                    <p class="description" style="display: inline;">Find the URL of your distributor's site in the Account Details section.</p>
                    <p class="description">Site Url eg. like <b>https://example.com/</b></p>
                </td>
            </tr>
        </table>
    </div>  
    <p class="auth_check_btn">
        <input type="button" name="auth_check_btn" id="auth_check_btn" class="button button-primary" value="Verify">
    </p>

    <div class="verify_msg"></div>
</section>

<script type="text/javascript">
    jQuery('#auth_check_btn').click(function(){
        var retailer_key_id = jQuery('#retailer_key_id').val();
        var retailer_id     = jQuery('#retailer_id').val();
        var distributor_url = jQuery('#distributor_url').val();

        jQuery.ajax({
            type: "post",
            dataType: "json",
            url: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
            data : {
                retailer_key_id: retailer_key_id,
                retailer_id: retailer_id,
                distributor_url: distributor_url,
                action: "retailer_key_verify"
            },
            success: function(response){
                jQuery('.verify_msg').html(response.message);

                if (response.message == 'Retailer Key Verified') {
                    setTimeout(function(){
                        location.reload();
                    }, 5000);
                }
            }
        });
    });
</script>