<?php

function single_distributor_details($retailer_key_id, $retailer_id){

    global $wpdb;

    $distributor_table = $wpdb->prefix.'distributor_list';
    $distributor_query = $wpdb->prepare("SELECT * FROM $distributor_table WHERE retailer_id = $retailer_id AND retailer_key_id = '$retailer_key_id'");
    $distributors = $wpdb->get_results($distributor_query);
    $distributor_url = $distributors[0]->distributor_url;

    $verify_retailer = verify_retailers_key($retailer_key_id, $retailer_id, $distributor_url);
    $verify_retailer_response = json_decode($verify_retailer, true);

    if ($verify_retailer_response['insert_in'] == true) {
        $products_categories = distributor_products_categories($retailer_id, $retailer_key_id, $distributor_url);
        $cat_list = json_decode($products_categories, true);

        $categories = $cat_list['data']['categories'];
    }

    ?>    
        <div class="distributor_site_key">
            <p>Distributor Site Url : <b><a href="<?php echo $distributor_url; ?>" target="_blank"><?php echo $distributor_url; ?></a></b></p>
            <input type="hidden" name="retailer_key_id" id="retailer_key_id" value="<?php echo $retailer_key_id; ?>">
            <input type="hidden" name="retailer_id" id="retailer_id" value="<?php echo $retailer_id; ?>">
            <input type="hidden" name="distributor_url" id="distributor_url" value="<?php echo $distributor_url; ?>">
        </div>
        <div class="distributor_product_list">
            <!--  Distributor Product Category List-->
            <h3 class="title"><?php echo $cat_list['message']; ?></h3>
            <h4 class="total_cat"><p><b>Total categories ( <?php echo $cat_list['data']['count']; ?> )</b></p></h4>
            <div class="product_list">
                <?php
                    foreach ($categories as $key => $category) {

                        if ($category['product_count'] >= 1) {
                            $product_count = $category['product_count'];
                        }else{
                            $product_count = '0';
                        }

                        echo '<p class="product_cat_list"><input type="checkbox" name="category[]" class="selected_cat_id" id="cat-id_'.$category['term_id'].'" value="'.$category['name'].'" term-id="'.$category['term_id'].'"/><label for="cat-id_'.$category['term_id'].'">'.$category['name'].' ('.$product_count.')</label></p>';
                    }
                ?>
            </div>

            <!-- 
            <link href="https://unpkg.com/bootstrap@3.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
            <script src="https://unpkg.com/jquery@3.3.1/dist/jquery.min.js"></script>
            <script src="https://unpkg.com/bootstrap@3.3.2/dist/js/bootstrap.min.js"></script>
            <script src="https://unpkg.com/bootstrap-multiselect@0.9.13/dist/js/bootstrap-multiselect.js"></script>
            <link href="https://unpkg.com/bootstrap-multiselect@0.9.13/dist/css/bootstrap-multiselect.css" rel="stylesheet"/>

            <form id="form1">
              <div style="padding:20px">

                <select id="chkveg" multiple="multiple">
                  <option value="cheese">Cheese</option>
                  <option value="tomatoes">Tomatoes</option>
                  <option value="mozarella">Mozzarella</option>
                  <option value="mushrooms">Mushrooms</option>
                  <option value="pepperoni">Pepperoni</option>
                  <option value="onions">Onions</option>
                </select>
                
              </div>
            </form> 
            -->

            <div class="import_product_btn">
                <button type="button" class="button product_import">Import Product</button>
            </div>
        </div>
    <?php
}

